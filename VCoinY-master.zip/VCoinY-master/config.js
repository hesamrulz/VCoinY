module.exports = {
    VK_TOKEN: "",
    DONEURL: ""
};
