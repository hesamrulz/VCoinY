#! /bin/sh
npm i --loglevel=error
exit 0
